package com.teste_target.victor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VictorApplication {

	public static void main(String[] args) {
		SpringApplication.run(VictorApplication.class, args);
	}

}
