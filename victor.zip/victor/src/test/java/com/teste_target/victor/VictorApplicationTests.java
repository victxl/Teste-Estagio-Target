package com.teste_target.victor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VictorApplicationTests {

	@Test
	void contextLoads() {
	}

}
